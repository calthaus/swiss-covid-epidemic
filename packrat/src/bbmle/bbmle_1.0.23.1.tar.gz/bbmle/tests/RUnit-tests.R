require(RUnit)
## TODO -- find solution to run these tests on R-forge

##testsuite <- defineTestSuite("phylobase", dirs="/home/francois/Work/R-dev/phylobase/branches/fm-branch/RUnit-tests",
##                             testFileRegexp="^test", testFuncRegexp="^test")
##testRslt <- runTestSuite(testsuite)
##printTextProtocol(testRslt)
